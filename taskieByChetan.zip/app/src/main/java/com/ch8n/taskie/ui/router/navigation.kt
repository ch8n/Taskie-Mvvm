package com.ch8n.taskie.ui.router

interface Router {
    fun toLoginScreen()
    fun toHomeScreen()
}